<?php
session_start();
require 'funciones.php';

require 'vendor/autoload.php';

  if(isset($_GET['id']) && is_numeric($_GET['id'])){
      $id = $_GET['id'];
    
      $articulo = new Kawschool\Articulo;
      $resultado = $articulo->mostrarPorId($id);

      if(!$resultado)
          header('Location: index.php');

  }else{
    header('Location: index.php');
  }

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Figurama</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="assets/css/barra.css">
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top" style="background-color:orange;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Figurama</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">CATEGORIAS<span class="caret"></span></a>
              <ul class="dropdown-menu">
              <?php
              require 'vendor/autoload.php';
              $categoria = new Kawschool\Categoria;
              $info_categoria = $categoria->mostrar();
              $x = 0;
              $item = $info_categoria[$x];
              $x++;
              ?>
              <li><a href="categorias/1.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/2.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/3.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/4.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/5.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/6.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/7.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/8.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/9.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="categorias/10.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              </ul>
            </li>
            <li>
              <a href="carrito.php" class="btn">CARRITO <span class="badge"><?php print cantidadArticulos(); ?></span></a>
            </li> 
            <li>
              <a href="panel" class="btn">Login</a>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
    <div class="row">
          <div class="col-md-12">
            <fieldset>
                <?php
                    require 'vendor/autoload.php';
                    $id = $_GET['id'];
                    $articulo = new Kawschool\Articulo;
                    $info_articulo = $articulo->mostrarPorId($id);
                    $item = $info_articulo;
                    $x = $info_articulo['categoria_id'];
                    
                ?>

                <legend>Información del Articulo <?php print $info_articulo['titulo'] ?></legend>
                <div class="pull-left">
                    <label>Foto</label>
                      <?php
                          $foto = 'upload/'.$item['foto'];
                          if(file_exists($foto)){
                        ?>
                          <img src="<?php print $foto; ?>" class="img-responsive">
                      <?php }else{?>
                        <img src="assets/imagenes/not-found.jpg" class="img-responsive">
                      <?php }?>
                      </div>
                </div>
                <div class="form-group">
                    <label> ID Articulo</label>
                    <input value="<?php print $info_articulo['id'] ?>" type="text" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label>Nombre</label>
                    <input value="<?php print $info_articulo['titulo'] ?>" type="text" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label>Descripción</label>
                    <textarea class="form-control" name="descripcion" id="" cols="10" readonly style="margin: 0px 0px 0px 0px; width: 600px; height: 280px;"><?php print $info_articulo['descripcion']?></textarea>
                </div>
                <div class="form-group">
                    <label>Precio</label>
                    <input value="<?php print $info_articulo['precio'] ?>" type="text" class="form-control" readonly>
                </div>
                <div class="form-group">
                    <label>Categoria</label>
                        <?php
                            require 'vendor/autoload.php';
                                $categoria = new Kawschool\Categoria;
                                $info_categoria = $categoria->mostrar();
                                $nom = $info_categoria[$x-1];
                            ?>
                    <input value="<?php print $info_articulo['categoria_id'] ?> - <?php print $nom['nombre'] ?>" type="text" class="form-control" readonly>
                </div>
            <fieldset>
            <div class="pull-left">
                <a href="index.php" class="btn btn-success">Regresar</a>
            </div>
            <div class="pull-right">
                <a href="carrito.php?id=<?php print $item['id'] ?>" class="btn btn-warning">Agregar al carrito</a>
            </div>
        </div>
      </div>
      
    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

  </body>
</html>
