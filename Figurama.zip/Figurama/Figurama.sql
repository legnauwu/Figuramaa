-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 17-05-2021 a las 01:54:13
-- Versión del servidor: 10.1.25-MariaDB
-- Versión de PHP: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `hardware_shop`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `articulos`
--

CREATE TABLE `articulos` (
  `id` int(11) NOT NULL,
  `titulo` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `descripcion` varchar(300) COLLATE utf8_spanish_ci NOT NULL,
  `foto` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `categoria_id` int(10) NOT NULL,
  `fecha` date NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `articulos`
--

INSERT INTO `articulos` (`id`, `titulo`, `descripcion`, `foto`, `precio`, `categoria_id`, `fecha`, `estado`) VALUES
(1, 'AXT', 'EXELENTE FUENTE DE PODER PARA USO DOMESTICO', 'axt.jpg', '510.00', 1, '2021-05-11', 1),
(2, 'AXT GAMING', 'EXELENTE FUENTE DE PODER PARA EL AREA DE LOS VIDEOJUEGOS', 'axt_gaming.jpg', '1500.00', 1, '2021-05-11', 1),
(3, 'PROCESADOR I3 ', 'OCTAVA GENERACION', 'i3_octava_generacion.jpg', '2809.00', 4, '2021-05-11', 1),
(4, 'PROCESADOR I5', 'OCTAVA GENERACION', 'i5_octava_generacion.jpg', '4639.00', 4, '2021-05-11', 1),
(5, 'MEMORIA RAM 8 GB', 'MARCA KINGSTON NUEVA', 'kingston_8gb.jpg', '1333.50', 3, '2021-05-11', 1),
(6, 'GABINETE GAMER ATX', 'DE CRISTAL TEMPLADO CON 4 VENTILADORES RGB', '61pY-EhYQfL._AC_SL1000_.jpg', '2099.00', 6, '2021-05-13', 1),
(9, 'Procesador Core i 7 Octava generación', 'Intel Core i7-8700K - Procesador ( 8ª generación de procesadores Intel Core i7, 3.7 GHz, 12MB Smart Cache, PC, 14 nm, 8 GT/s)', 'hardware3.jpg', '8000.00', 4, '2021-05-12', 1),
(10, 'Tarjeta Grafica gtx 1050Ti', 'Interfaz PCI-Express 3.0.\r\nMemoria gráfica GDDR5 de 7008MHz.\r\nBus de memoria: 128bit.\r\nCantidad de núcleos: 768.\r\nFrecuencia boost del núcleo de 1392MHz y base de 1290MHz.\r\nResolución máxima: 7680x4320.', 'hardware11.jpg', '3000.00', 8, '2021-05-13', 1),
(11, 'Procesador Core i 9 Septima generación', 'Procesador Intel Core i9-7980XE Extreme Edition, S-2066, 2.60GHz, 18-Core, 24,75 MB Smart Caché (9na Generación - Skylake)', 'i9_septima_generacion.jpg', '13000.00', 4, '2021-05-13', 1),
(12, 'Memoria ram 8gb', 'Memoria RAM HyperX FURY Black DDR4, 3200MHz, 8GB, Non-ECC, CL16, XMP', 'hardware15.jpg', '800.00', 3, '2021-05-12', 1),
(13, 'Procesador ryzen 5 3600', 'Memoria caché de 32 MB, rápida y volátil.\r\nSoporta memoria RAM DDR4.\r\nSu potencia es de 65 W.\r\nCuenta con 12 hilos que favorecen la ejecución de múltiples programas a la vez.', 'hardware4.jpg', '4500.00', 4, '2021-05-12', 1),
(14, 'Ryzen 7 3700X', '\r\n# de núcleos de CPU\r\n8\r\n# de hilos\r\n16\r\nReloj base\r\n3.6GHz\r\nReloj de aumento máx. \r\nHasta 4.4GHz\r\nCaché L1 total\r\n512KB\r\nCaché L2 total\r\n4MB\r\nCaché L3 total\r\n32MB', 'hardware5.jpg', '6500.00', 4, '2021-05-12', 1),
(15, 'Ryzen 9 3900X', 'Procesador AMD Ryzen 9 3900X, S-AM4, 3.80GHz, 12-Core, 64MB L3, con Disipador Wraith Prism RGB', 'hardware6.jpg', '9000.00', 4, '2021-05-12', 1),
(16, 'Tarjeta Madre H410M-HDV', 'Soporta Procesadores Intel® Core™ 10ª Gen (Socket 1200)\r\nSoporta memoria DDR4 2933MHz\r\n1 PCIe 3.0 x16, 1 PCIe 3.0 x1\r\nOpciones de salida gráficos : HDMI, D-Sub, DVI\r\nAudio 7.1 canales HD (Códec de audio Realtek ALC887)\r\n4 SATA3\r\n4 USB 3.2 Gen1 (2 Frontales, 2 Traseros)', 'hardware7.jpg', '2100.00', 5, '2021-05-13', 1),
(17, 'Tarjeta Madre Z490 Pro', 'Tarjeta Madre AORUS ATX Z490 PRO AX (rev. 1.x), S-1200, Intel Z490, HDMI, 128GB DDR4 para Intel', 'hardware8.jpg', '7500.00', 5, '2021-05-13', 1),
(18, 'Tarjeta Madre A520 S2H', 'Tarjeta Madre Gigabyte micro ATX A520M S2H, S-AM4, AMD A520, HDMI, 64GB DDR4 para AMD ― No es Compatible con Ryzen 5 3400G y Ryzen 3 3200G', 'hardware9.jpg', '1600.00', 5, '2021-05-13', 1),
(19, 'Tarjeta Madre B550M-K', 'Tarjeta Madre ASUS Micro ATX PRIME B550M-K, S-AM4, AMD B550, HDMI, 128GB DDR4 para AMD', 'hardware10.jpg', '2200.00', 5, '2021-05-13', 1),
(20, 'Tarjeta Grafica gtx 1650Ti', 'Tarjeta de Video ASUS NVIDIA Phoenix GeForce GTX 1650 Gaming OC, 4GB 128-bit GDDR6, PCI Express x16 3.0', 'hardware12.jpg', '5000.00', 8, '2021-05-13', 1),
(21, 'Tarjeta Grafica 2080Ti', 'Tarjeta de Video ASUS NVIDIA GeForce RTX 2060 Dual OC EVO, 6GB 192-bit GDDR6, PCI Express 3.0', 'hardware13.jpg', '15000.00', 8, '2021-05-13', 1),
(22, 'Disco Duro 1Tb', 'Disco Duro Interno Seagate Barracuda 3.5\'\', 1TB, SATA III, 6 Gbit/s, 7200RPM, 64MB Cache', 'hardware16.jpg', '900.00', 7, '2021-05-13', 1),
(23, 'Disco SSD 1 Tb', 'SSD Kingston A400, 960GB, SATA III, 2.5\'\', 7mm', 'hardware17.jpg', '2000.00', 7, '2021-05-13', 1),
(24, 'Gabinete Gamer Yeiyan', 'Gabinete Yeyian Blade 2100 con Ventana LED Azul, Midi-Tower, ATX/Micro-ATX, USB 2.0/3.1, sin Fuente, Negro', 'hardware18.jpg', '900.00', 6, '2021-05-13', 1),
(25, 'Gabinete Gamer Yeiyan Negro', 'Gabinete Yeyian ABYSS 2500 con Ventana RGB, Midi-Tower, ATX/EATX/ITX/Micro ATX, USB 3.0, sin Fuente, Negro', 'hardware19.jpg', '1400.00', 6, '2021-05-13', 1),
(26, 'Fuente de Poder PSG400', 'Tipo de fuente de poder para PC: ATX\r\nTipo de refrigeración: Por aire\r\nCon protección de bajo voltaje: Sí\r\nCon iluminación RGB: No\r\nCantidad de conectores HDD: 5\r\nCantidad de conectores SATA: 5\r\nCertificación de eficiencia: 80 Plus Bronze\r\nCorrección del factor de potencia: Activo', 'hardware20.jpg', '900.00', 1, '2021-05-12', 1),
(27, 'Memoria Ram Kingston 16 Gb', 'Memoria con formato RDIMM.\r\nAlcanza una velocidad de 1333 MHz.\r\nApta para Servidores.\r\nCuenta con una tasa de transferencia de 10600 MB/s.', 'kingston_16gb.jpg', '1500.00', 3, '2021-05-13', 1),
(28, 'Memoria Ram Kingston 32 Gb', 'Capacidad total: 32 GB\r\n\r\nEs gamer: No\r\n\r\nFormato: RDIMM\r\n\r\nTecnología: DDR3\r\n\r\nVelocidad: 1600 MHz\r\n\r\nAplicación: Servidores', 'kingston_32gb.jpg', '3000.00', 3, '2021-05-13', 1),
(29, 'Game Factor Teclado Mecánico Gamer KBG400-RD', 'Voltaje: 5 V cc, 250mA\r\nConector y Alimentación: USB\r\nPlug and play: Si\r\nTeclas: 104, FNMultimedia\r\nIdioma: Español\r\nCompatibilidad: Windows XP, 7, 8, 10\r\nDimensiones: 436 x 129 x 35mm Peso: 810g Longitud Cable: 1.8m', '616MBUv8LmL._AC_SY355_.jpg', '1000.00', 9, '2021-05-13', 1),
(30, 'Teclado mecanico K550 Rgb-1 Yama Redragon', 'Marca superior: Redragon K550 de aluminio USB mecánico para juegos teclado RGB rojo púrpura interruptor bricolaje clave ergonómica retroiluminada anti-fantasma PC Pro Gamer chip inteligente proporciona una buena funcionalidadTal como 100% anti-fantasma y velocidad de respuesta de milisegundos interr', 'descarga.jpg', '1600.00', 9, '2021-05-13', 1),
(31, 'Mouse Gamer Logitech G203', 'Sensor de alta precisión con DPI ajustable hasta 8000 DPI\r\nIluminación RGB LIGHTSYNC\r\nLIGHTSYNC RGB personalizable con efecto de onda de color personalizable con aproximadamente 16,8 millones de colores\r\nDiseño de 6 botones probado con el tiempo con botones programables usando Software Logitech G HU', '910-005793031657_xg.jpg', '450.00', 10, '2021-05-13', 1),
(34, 'Teclado Gamer Extendido Ocelot Gaming - Membrana', 'Teclado completo gamer de membrana con cuerpo metálico, cuenta con teclas multimedia, estilo de iluminación arcoíris donde puedes elegir entre 3 estilos distintos para iluminar tu teclado\r\n21 teclas anti ghosting para una mejor experiencia\r\n104 teclas en total cuenta con teclado numérico, diseño res', '619MHX-XijL._AC_SY355_.jpg', '300.00', 9, '2021-05-13', 1),
(35, 'Mouse Gamer Game Factor Mog601 Rgb Laser', 'Equipado con el sensor tope de gama Pixart 3389 de 16,000 DPI nativos totalmente flawless.\r\n-Hasta 32,00 DPI interpolados con procesamiento interno, ideal para setups multi pantalla o altas resoluciones.\r\n-Extremadamente ligero, ideal para largas sesiones de juego y arrastre ligero.\r\n-7 Botones', '4d786bc5bb632409158bd5ca084931ce.jpg', '500.00', 10, '2021-05-16', 1),
(36, 'Gabinete Gamer Atx Ocelot Ogmc01 Panel De Cristal', 'Cristal Templado\r\nIncluye fuente de alimentación: No\r\nTipo de estructura: Mid tower\r\nPuertos: 2x USB 2.0,1x USB 3.0,Audio HD\r\nBahías: 4x2.5\",2x3.5\"\r\nAltura x Ancho x Largo: 45.5 cm x 20.5 cm x 40.5 cm\r\nEs gamer: Sí', 'descarga (1).jpg', '1200.00', 6, '2021-05-13', 1),
(37, 'Gabinete Gamer Aerocool Klaw Rgb Atx ', 'Cristal Templado\r\nVENTILADORES ADDRESSABLE RGB INCLUIDOS\r\nViene equipado con dos ventiladores RGB direccionables de 12 cm en la parte superior y un ventilador RGB direccionable de 12 cm en la parte posterior de la caja.\r\nCon iluminación de doble anillo y un diseño de anillo fino, estos ventiladores ', 'descarga (2).jpg', '1800.00', 6, '2021-05-13', 1),
(38, 'Core I5 11va Generacion Modelo 11400f Lga1200', 'Tipos de memoria RAM soportadas: DDR4\r\n\r\nCantidad de núcleos de CPU: 6\r\n\r\nZócalos compatibles: Intel LGA1200\r\n\r\nGeneración: 11\r\n\r\nFrecuencia máxima de reloj: 4.9 GHz', 'images.jpg', '5000.00', 4, '2021-05-13', 1),
(39, 'Monitor Gamer Curvo MSI Optix G241VC', 'Diagonal de la pantalla: 59,9 cm (23.6\")\r\nTipo HD: Full HD\r\nResolución: 1920 x 1080 Pixeles\r\nNvidia G-Sync:  No\r\nAMD FreeSync:  Si\r\nTiempo de respuesta: 1 ms\r\nVelocidad de actualización: 75 Hz\r\nCantidad de puertos HDMI: 1\r\nAltavoces incorporados:  No\r\nColor del producto: Negro', 'CP-MSI-OPTIXG241VC-1.jpg', '3459.00', 2, '2021-05-16', 1),
(40, 'Monitor Gamer Curvo AOC C27G1', 'Diagonal de la pantalla: 68,6 cm (27\")\r\nTipo HD: Full HD\r\nResolución: 1920 x 1080 Pixeles\r\nNvidia G-Sync:  No\r\nAMD FreeSync:  Si\r\nTiempo de respuesta: 4 ms\r\nVelocidad de actualización: 144 Hz\r\nCantidad de puertos HDMI: 2\r\nAltavoces incorporados:  No\r\nColor del producto: Negro', 'CP-AOC-C27G1-1.jpg', '5899.00', 2, '2021-05-16', 1),
(41, 'Monitor Gamer Game Factor MG700', 'Diagonal de la pantalla: 68,6 cm (27\")\r\nTipo HD: Quad HD\r\nResolución: 2560 x 1440 Pixeles\r\nNvidia G-Sync:  No\r\nAMD FreeSync:  Si\r\nTiempo de respuesta: 1 ms\r\nVelocidad de actualización: 144 Hz\r\nCantidad de puertos HDMI: 3\r\nAltavoces incorporados:  No\r\nColor del producto: Negro', 'CP-GAMEFACTOR-MG700-1.jpg', '4919.00', 2, '2021-05-17', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias`
--

CREATE TABLE `categorias` (
  `id` int(10) NOT NULL,
  `nombre` varchar(50) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `categorias`
--

INSERT INTO `categorias` (`id`, `nombre`) VALUES
(1, 'FUENTES DE PODER'),
(2, 'MONITORES'),
(3, 'MEMORIAS RAM'),
(4, 'PROCESADORES'),
(5, 'TARJETAS MADRE'),
(6, 'GABINETES'),
(7, 'ALMACENAMIENTO'),
(8, 'TARJETAS GRAFICAS'),
(9, 'TECLADOS'),
(10, 'MOUSE');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id` int(10) NOT NULL,
  `nombre` varchar(80) COLLATE utf8_spanish_ci NOT NULL,
  `apellidos` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `email` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `telefono` varchar(15) COLLATE utf8_spanish_ci NOT NULL,
  `comentario` varchar(300) COLLATE utf8_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id`, `nombre`, `apellidos`, `email`, `telefono`, `comentario`) VALUES
(1, 'Brandon Arturo', 'Diaz Orzua', 'brandon10_2001@hotmail.com', '11037', 'qwedqd'),
(2, 'Lizbeth', 'Lopez', 'lizlopez@hotmail.com', '21312312', 'Gracias'),
(3, 'Carlos Alejandro', 'Gonzalez Solis', 'charlybtrax@hotmail.com', '8114948899', 'Excelentes productos');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalle_pedidos`
--

CREATE TABLE `detalle_pedidos` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) NOT NULL,
  `articulo_id` int(11) NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `detalle_pedidos`
--

INSERT INTO `detalle_pedidos` (`id`, `pedido_id`, `articulo_id`, `precio`, `cantidad`, `estado`) VALUES
(1, 1, 6, '2099.00', 1, 1),
(2, 1, 5, '1333.50', 1, 1),
(3, 1, 4, '4639.00', 1, 1),
(4, 2, 25, '1400.00', 1, 1),
(5, 2, 28, '3000.00', 4, 1),
(6, 2, 22, '900.00', 1, 1),
(7, 3, 4, '4639.00', 1, 1),
(8, 3, 28, '3000.00', 100, 1),
(9, 3, 19, '2200.00', 1, 1),
(10, 3, 20, '5000.00', 1, 1),
(11, 3, 2, '1500.00', 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(10) NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `total` decimal(10,2) NOT NULL,
  `fecha` date NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id`, `cliente_id`, `total`, `fecha`, `estado`) VALUES
(1, 1, '8071.50', '2021-05-11', 1),
(2, 2, '14300.00', '2021-05-13', 1),
(3, 3, '313339.00', '2021-05-12', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nombre_usuario` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `clave` varchar(150) COLLATE utf8_spanish_ci NOT NULL,
  `estado` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `nombre_usuario`, `clave`, `estado`) VALUES
(1, 'sa', '123', 1),
(2, 'admin', '1234', 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `articulos`
--
ALTER TABLE `articulos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `detalle_pedidos`
--
ALTER TABLE `detalle_pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `articulos`
--
ALTER TABLE `articulos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT de la tabla `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `detalle_pedidos`
--
ALTER TABLE `detalle_pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
