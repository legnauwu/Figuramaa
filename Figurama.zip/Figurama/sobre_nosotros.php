<?php
session_start();
require 'funciones.php';

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Figurama</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/estilos.css">
  </head>

  <body>

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top" style="background-color:orange;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="index.php">Figurama</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li class="active">
              <a href="sobre_nosotros.php" class="btn">SOBRE NOSOTROS</a>
            </li>
            
            <li>
              <a href="carrito.php" class="btn">CARRITO <span class="badge"><?php print cantidadArticulos(); ?></span></a>
            </li> 
            <li>
              <a href="panel" class="btn">Login</a>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">
        <div class="row">
            <div class="jumbotron">
                <p>SOBRE NOSOTROS</p>
                <p>Equipo 6</p>
                <table>
                  <tr class="mover">
                  <th class="mover">Nombre Completo</th>
                  <th>Matricula</th>
                  <th class="mover">Carrera</th>
                  
                   </tr>
                  
                  <tr class="mover">
                   <td> Edgar Adrian Mier Alanis</td>
                   <td>1877195</td>
                   <td>ITS</td>
                   
                   </tr>
                  
                   <tr class="mover">
                   <td>Ángel Armando Hernández Dávila </td>
                   <td>1902084</td>
                   <td>ITS</td>
                   
                   </tr>

                   <tr class="mover">
                   <td>Rubén Alberto Mejía Barrientos</td>
                   <td>1986730</td>
                   <td>ITS</td>
                   
                   </tr>

                   <tr class="mover">
                   <td>Hector Israel Bocanegra Pinales</td>
                   <td>1905884</td>
                   <td>ITS</td>
                   
                   </tr>

                   <tr class="mover">
                   <td>Orlando Isaí Gómez García</td>
                   <td>1930818</td>
                   <td>ITS</td>
                   
                   </tr>

                  </table>
                <h2>Figurama</h2>
                <h3>Objetivo principal</h3>
                <p>"Somos una tienda en línea especializada en figuras de colección de anime para fanáticos y coleccionistas. En nuestra tienda, encontrarás una amplia selección de figuras de alta calidad de tus personajes favoritos de anime, desde los clásicos hasta los más nuevos. Nos apasiona el anime tanto como tú y nos enorgullece ofrecer productos de la mejor calidad y a precios justos. </p>
                <p>
                    <a href="index.php">Regresar</a>
                </p>
            </div>



        </div>
      

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.min.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

  </body>
</html>
