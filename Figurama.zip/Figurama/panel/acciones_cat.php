<?php
require '../vendor/autoload.php';

$categoria = new Kawschool\Categoria;

if($_SERVER['REQUEST_METHOD'] ==='POST'){

    if ($_POST['accion']==='Registrar'){

        if(empty($_POST['nombre']))
            exit('Completar nombre');
        
        $_params = array(
            'nombre'=>$_POST['nombre'],
        );

        $rpt = $categoria->registrar($_params);

        if($rpt)
            header('Location: categorias/index.php');
        else
            print 'Error al registrar la categoria';
        

    }

    if ($_POST['accion']==='Actualizar'){

        if(empty($_POST['nombre']))
        exit('Completar nombre');

    
    $_params = array(
        'nombre'=>$_POST['nombre'],
        'id'=>$_POST['id'],
    );

    $rpt = $categoria->actualizar($_params);
    if($rpt)
        header('Location: categorias/index.php');
    else
        print 'Error al actualizar la categoria';

    }

}

if($_SERVER['REQUEST_METHOD'] ==='GET'){

    $id = $_GET['id'];

    $rpt = $categoria->eliminar($id);
    
    if($rpt)
        header('Location: categorias/index.php');
    else
        print 'Error al actualizar la categoria';


}



