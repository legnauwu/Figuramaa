<?php
session_start();
require '../funciones.php';

?>
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Hardware Shop</title>

    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <link rel="stylesheet" href="../assets/css/barra.css">
  </head>

  <body style="background-color:black;">

    <!-- Fixed navbar -->
    <nav class="navbar navbar-default navbar-fixed-top" style="background-color:orange;">
      <div class="container">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="../index.php">Figurama</a>
        </div>
        <div id="navbar" class="navbar-collapse collapse">
          <ul class="nav navbar-nav pull-right">
            <li>
              <a href="../sobre_nosotros.php" class="btn">SOBRE NOSOTROS</a>
            </li>
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">CATEGORIAS<span class="caret"></span></a>
              <ul class="dropdown-menu">
              <?php
              require '../vendor/autoload.php';
              $categoria = new Kawschool\Categoria;
              $info_categoria = $categoria->mostrar();
              $x = 0;
              $item = $info_categoria[$x];
              $x++;
              ?>
              <li><a href="1.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li class="active"><a href="2.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="3.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="4.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="5.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="6.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="7.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="8.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="9.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              <?php $item = $info_categoria[$x]; $x++; ?>
              <li><a href="10.php"><?php print $item['id'] ?> - <?php print $item['nombre'] ?></a></li>
              </ul>
            </li>
            <li>
              <a href="../carrito.php" class="btn">CARRITO <span class="badge"><?php print cantidadArticulos(); ?></span></a>
            </li> 
            <li>
              <a href="../panel" class="btn">Login</a>
            </li>
          </ul>
        </div><!--/.nav-collapse -->
      </div>
    </nav>

    <div class="container" id="main">

        <div class="row">
            <?php
              require '../vendor/autoload.php';
              $articulo = new Kawschool\Articulo;
              $info_articulos = $articulo->mostrarPorC2();
              $cantidad = count($info_articulos);
              if($cantidad > 0){
                for($x =0; $x < $cantidad; $x++){
                  $item = $info_articulos[$x];
            ?>
              <div class="col-md-3">
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h1 class="text-center titulo-articulo"><?php print $item['titulo'] ?></h1>  
                    </div>
                    <div class="panel-body">
                      <?php
                          $foto = '../upload/'.$item['foto'];
                          if(file_exists($foto)){
                        ?>
                          <img src="<?php print $foto; ?>" class="img-responsive">
                      <?php }else{?>
                        <img src="../assets/imagenes/not-found.jpg" class="img-responsive">
                      <?php }?>
                    </div>
                    <?php
                      $estado = $item['estado'];
                      if($estado == 1){
                    ?>
                      <h1 class="text-center disponible">Disponible</h1>
                    <?php }else{ ?>
                      <h1 class="text-center noDisponible">No disponible</h1>
                    <?php } ?>
                    <h1></h1>
                    <div class="panel-footer">
                        <h1 class="text-center titulo-articulo">$ <?php print $item['precio'] ?></h1>
                        <h1></h1>
                        <a href="../detalles.php?id=<?php print $item['id'] ?>" class="btn btn-primary btn-block">
                          <span class="glyphicon glyphicon-paperclip"></span> Detalles
                          <a href="../carrito.php?id=<?php print $item['id'] ?>" class="btn btn-success btn-block">
                          <span class="glyphicon glyphicon-shopping-cart"></span> Agregar al carrito
                        </a>
                    </div>
                  </div>
              
              
              </div>
          <?php
                }
            }else{?>
              <h4>NO HAY REGISTROS</h4>

          <?php }?>




        </div>
      

    </div> <!-- /container -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

  </body>
</html>
