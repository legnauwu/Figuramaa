<?php

namespace Kawschool;

class Usuario {
    private $config;
    private $cn = null;

    public function __construct() {
        $this->config = parse_ini_file(__DIR__.'/../config.ini');

        $dsn = $this->config['dns'];
        $user = $this->config['usuario'];
        $password = $this->config['clave'];

        $options = array(
            \PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8',
        );

        try {
            $this->cn = new \PDO($dsn, $user, $password, $options);
            $this->cn->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
        } catch (\PDOException $e) {
            throw new \PDOException($e->getMessage(), (int) $e->getCode());
        }
    }

    public function login($nombre, $clave) {
        $sql = "SELECT nombre_usuario FROM `usuarios` WHERE nombre_usuario = :nombre AND clave = :clave";
        $stmt = $this->cn->prepare($sql);

        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':clave', $clave);

        $stmt->execute();

        return $stmt->fetch();
    }
}